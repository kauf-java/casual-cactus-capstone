package capstone.cacti.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import capstone.cacti.entity.Cacti;

//This is the repository; it is utilizing a JPA and connects with the Cacti class with the Integer id "primary key"
@Repository
public interface CactiRepository extends JpaRepository<Cacti, Integer>{
	
	@Query("SELECT C FROM Cacti C")
	List<Cacti> getAllCacti();
	
	@Query("SELECT C FROM Cacti C WHERE normName = ?1")
	Cacti findCacti(String normName);
	
	@Query("SELECT C FROM Cacti C WHERE id = ?1")
	Cacti findCactiSet(Integer id);
}
