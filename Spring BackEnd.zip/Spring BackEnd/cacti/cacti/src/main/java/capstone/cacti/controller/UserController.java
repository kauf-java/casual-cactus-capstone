package capstone.cacti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import capstone.cacti.entity.Cacti;
import capstone.cacti.entity.User;
import capstone.cacti.repository.CactiRepository;
import capstone.cacti.repository.UserRepository;
import capstone.cacti.service.CactiService;

@CrossOrigin
@RestController
@ComponentScan(basePackages="capstone.cacti")
public class UserController {
	
	@Autowired 
	UserRepository userRepository;
	
	@Autowired
	CactiRepository cactiRepository;
	
	@Autowired
	CactiService emailSender;
	
	@RequestMapping(value="/save",
					consumes=MediaType.APPLICATION_JSON_VALUE,
					produces=MediaType.APPLICATION_JSON_VALUE,
					method=RequestMethod.POST)
	public void submitUserDetails(@RequestBody User user) {
		userRepository.save(user);
		emailSender.send(user);
	}
	
	@RequestMapping(value="/login",
					consumes = MediaType.APPLICATION_JSON_VALUE,
					produces = MediaType.APPLICATION_JSON_VALUE,
					method = RequestMethod.POST)
	private ResponseEntity<User> userLogin(@RequestBody User user){
		User logInput = userRepository.userLogin(user.getEmail(), user.getPassword());
		if(logInput == null) {
			return new ResponseEntity<User>(HttpStatus.UNAUTHORIZED);
		}else {
			return new ResponseEntity<User>(HttpStatus.OK);
		}
	}
	
	@RequestMapping(value = "/findUserById",
					produces = MediaType.APPLICATION_JSON_VALUE,
					method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<User> findUser(String email) {
		User userInput = userRepository.find(email);
		return new ResponseEntity<User>(userInput, HttpStatus.OK);
	}
	
	@RequestMapping(value =  "/allUsers",
					produces = MediaType.APPLICATION_JSON_VALUE,
					method = RequestMethod.GET)
	@ResponseBody
		public ResponseEntity<List<User>> getAllCacti() {
			List<User> allUsers = userRepository.getAllUsers();
			return new ResponseEntity<List<User>>(allUsers, HttpStatus.OK);
	}
			
//	@RequestMapping(value="/addCacti",
//					produces=MediaType.APPLICATION_JSON_VALUE,
//					consumes=MediaType.APPLICATION_JSON_VALUE,
//					method=RequestMethod.PUT)
//	public void addCacti(@RequestBody Cacti cacti) {
//		User userUpdate = userRepository.find(cacti.getUser().getEmail());
//		
//
//	}

}
