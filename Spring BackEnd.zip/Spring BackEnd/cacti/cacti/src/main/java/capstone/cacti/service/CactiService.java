package capstone.cacti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import capstone.cacti.entity.User;

@Service
public class CactiService {
	
	@Autowired
	private JavaMailSender emailSender;
	
	public void send(User user) {
		SimpleMailMessage simple = new SimpleMailMessage();
		simple.setTo(user.getEmail());
		simple.setSubject("Welcome to your planting journey!");
		simple.setText("We welcome you to our website the Casual Cacti! We are excited to have you onboard your journey in the wonderful world of Succulents and "
				+ "Cacti. You will be able to find information on how to properly care for these wonderful plants.");
		emailSender.send(simple);
	}

}
