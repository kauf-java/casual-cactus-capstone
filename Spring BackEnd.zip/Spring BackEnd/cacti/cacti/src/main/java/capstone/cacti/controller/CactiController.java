package capstone.cacti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import capstone.cacti.entity.Cacti;
import capstone.cacti.entity.User;
import capstone.cacti.repository.CactiRepository;

@CrossOrigin
@RestController
@ComponentScan(basePackages="capstone.cacti")
public class CactiController {
	
	@Autowired
	CactiRepository cactiRepository;
	
	//Returns the list of all cacti & Succulents
	@RequestMapping(value =  "/allCacti",
					produces = MediaType.APPLICATION_JSON_VALUE,
					method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<List<Cacti>> getAllCacti() {
		List<Cacti> allCacti = cactiRepository.getAllCacti();
		return new ResponseEntity<List<Cacti>>(allCacti, HttpStatus.OK);
	}
	
	@RequestMapping(value="/saveCacti",
					consumes=MediaType.APPLICATION_JSON_VALUE,
					produces=MediaType.APPLICATION_JSON_VALUE,
					method=RequestMethod.POST)
	public void submitUserDetails(@RequestBody Cacti cacti) {
		cactiRepository.save(cacti);
	}
	
	@RequestMapping(value = "/findCactiById",
			produces = MediaType.APPLICATION_JSON_VALUE,
			method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Cacti> findUser(String normName) {
		Cacti updateCacti = cactiRepository.findCacti(normName);
		return new ResponseEntity<Cacti>(updateCacti, HttpStatus.OK);
	}
	
	@RequestMapping(value="/updateCacti",
					consumes=MediaType.APPLICATION_JSON_VALUE,
					produces=MediaType.APPLICATION_JSON_VALUE,
					method=RequestMethod.PUT)
	public void updateCacti(@RequestBody Cacti cacti) {
		cactiRepository.save(cacti);
	}
	
	@RequestMapping(value="/deleteCacti",
					consumes=MediaType.APPLICATION_JSON_VALUE,
					produces=MediaType.APPLICATION_JSON_VALUE,
					method=RequestMethod.PUT)
	public void deleteCacti(@RequestBody Cacti cacti) {
		cactiRepository.delete(cacti);
	}
	
	

}
