package capstone.cacti.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import capstone.cacti.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, String>{
	
	@Query("SELECT U FROM User U Where U.email = ?1")
	User find(String email);
	
	@Query("SELECT U FROM User U WHERE U.email = ?1 AND U.password = ?2")
	User userLogin(String email, String password);
	
	@Query("SELECT U FROM User U")
	List<User> getAllUsers();
	
}
