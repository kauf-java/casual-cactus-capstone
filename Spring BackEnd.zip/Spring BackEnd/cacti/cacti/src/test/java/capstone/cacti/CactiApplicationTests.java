package capstone.cacti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CactiApplicationTests {

	@Test
	void contextLoads() {
	}

}
